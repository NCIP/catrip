Changes from version 1 to version 2
1 Attribute definition changed:
  Class:     RadiationFirstCourse
  Attribute: location
  old definition : Identifies the location of the facility where radiation treatment was administered 
                     during first course of treatment
  new definition : Identifies radiation type(s) given at reporting facility versus elsewhere during treatment course, 
                     where radiation type is regional or boost.