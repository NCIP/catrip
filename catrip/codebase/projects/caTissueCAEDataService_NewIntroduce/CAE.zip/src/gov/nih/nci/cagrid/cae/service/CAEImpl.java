package gov.nih.nci.cagrid.cae.service;

import java.rmi.RemoteException;

/** 
 *  TODO:DOCUMENT ME
 * 
 * @created by Introduce Toolkit version 1.0
 * 
 */
public class CAEImpl extends CAEImplBase {

	
	public CAEImpl() throws RemoteException {
		super();
	}
	
}

